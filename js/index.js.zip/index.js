var box = document.getElementsByClassName('box')[0];

function startDictation() {

  if (window.hasOwnProperty('webkitSpeechRecognition')) {

    var recognition = new webkitSpeechRecognition();

    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.lang = "en-US";
    recognition.start();

    recognition.onresult = function(e) {
      var t = setTimeout(function() {
        responsiveVoice.speak(document.getElementById("response").innerHTML);
      }, 1000)

      document.getElementById('transcript').value = e.results[0][0].transcript;
      recognition.stop();
      getword();
      document.getElementById('labnol').submit();

    };

    recognition.onerror = function(e) {
      recognition.stop();
    }

  }
}

var phrasePara = document.querySelector('.phrase');
var resultPara = document.querySelector('.result');
var diagnosticPara = document.querySelector('.output');

//resultPara
  resultPara.textContent = 'Right or wrong?';
  resultPara.style.background = 'rgba(0,0,0,0.2)';
  diagnosticPara.textContent = '...diagnostic messages';




//weather

$(document).ready(function() {
  $.simpleWeather({
    location: 'Washington DC',
    woeid: '',
    unit: 'f',
    success: function(weather) {
      html = '<p>' + weather.temp + '&deg;' + weather.units.temp + '</p>';

      $("#weather").html(html);
    },
    error: function(error) {
      $("#weather").html('<p>' + error + '</p>');
    }
  });
});

$(document).ready(function() {

  $(document).bind('keydown', function(e) {
    if (e.keyCode == 13) {
      getword(), box.classList.add('talk');
    }
  });
});


//Remove name




function getword() {

//var transcript = transcript.toLowerCase();
var input = get("transcript").value,
  
    frame = get("frame");
  var res = document.getElementById("response");


if(~input.indexOf("script")) {
  alert("Found")

//Remove first word 
var filinput = input.substring( input.indexOf(" ") + 1, input.length );

    

 var filtinput = filinput.toLowerCase();




////////////////////////////////////////////////////////////////////
  if (filtinput==="find images") {
    res.innerHTML = "Hi there! I'm alley.";
    resultPara.style.background = 'pink';
    box.classList.add('talk');
	
  } else if(filtinput==='turn on') {
      resultPara.textContent = 'Light Turn ON';
      resultPara.style.background = 'lime';
	  alert(input.match);
	
	  }else if(filtinput==='turn off') {
      resultPara.textContent = 'Light Turn OFF';
      resultPara.style.background = 'red';
	  alert(input.match);
	
	  

////////////////////////////////////////////////////////////////////

//END
}else {
  alert("Not Found");
}
////////





  }else {
    res.innerHTML = "I dont get what you said, please dont use capital letters.";
  }


}

function get(id) {
  return document.getElementById(id);
}
//CHECK CODE
//var t = setInterval(getword, 20)

function emptytime() {
  document.getElementById('txt').value = "";
  document.getElementById('transcript').value = "";

}

function emptyweather() {
  document.getElementById('txt').value = "";
  document.getElementById('transcript').value = "";

}

function Talkback() {
  responsiveVoice.speak(document.getElementById("response").innerHTML);
}

function Talktime() {
  responsiveVoice.speak(document.getElementById("txt").innerHTML);
}